# AMSAK Group of Schools: demo site

Static site, no build step. Upload the whole folder to the **root** of a domain or subdomain.

Routes: `/` home, `/admission`, `/student`, `/teacher`, `/admin`. The last two are not linked anywhere in the menu.

Hosting (every path must fall back to index.html):
- Vercel: vercel.json is included
- Netlify / Cloudflare Pages: _redirects is included
- Apache / cPanel: .htaccess is included
- GitHub Pages: 404.html is a copy of index.html (keep both in sync)

Demo logins: student `AMS/2026/001` + PIN `student`; teacher `TCH-014` + PIN `teacher`; admin any name + code `YUSUFTECH`.

Images in /images are illustrations. Replace them with real photos using the same file names (or edit the paths in index.html).

This is a demo: data is stored in the visitor's browser (localStorage) and logins are checked in the browser. A production build needs a server, a database and real authentication.
